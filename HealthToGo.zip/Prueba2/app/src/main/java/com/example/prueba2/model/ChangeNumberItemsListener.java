package com.example.prueba2.model;

public interface ChangeNumberItemsListener {
    void changed();
}
